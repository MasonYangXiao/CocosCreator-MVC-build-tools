import { _decorator, Prefab, Node, Sprite, SpriteFrame, Texture2D, Asset, error, instantiate, find, resources, isValid, assetManager, LoadCompleteCallback, Component, AssetManager } from "cc";
import { AssetType } from "../Configuration";
import { IResPkgModel } from "../IResPkgModel";

export class ResManager extends Component{

    public static instance : ResManager = null as unknown as ResManager;
    
    onload(): void{
        if(ResManager.instance===null){
            ResManager.instance = this;
        }else{
            this.destroy();
            return;
        }
    }
    private total: number = 0;
    private now: number = 0;
    private totalAb: number = 0;
    private nowAb: number = 0;
    // @ts-ignore
    private progressFunc:  ( now: number, total: number ) => void;
    // @ts-ignore
    private endFunc: () => void;
    // @ts-ignore
    private abBunds: Map<string, AssetManager.Bundle> = new Map<string,  AssetManager.Bundle>();
    protected onLoad(): void{
        if( !ResManager.instance ){
            ResManager.instance = this;
        }else{
            this.destroy();
            return;
        }
    }
    public preloadResPkg( resPkg:Map<string,IResPkgModel>, progressFunc: ( now: number, total: number ) => void, endFunc : () => void): void{
        // step1: 加载我们的ab包进来
        this.total = 0;
        this.now = 0;
        this.totalAb = 0;
        this.nowAb = 0;
        this.progressFunc = progressFunc;//进度函数
        this.endFunc = endFunc;//结束函数
        let keys: IterableIterator<string> = resPkg.keys();
        let resultKey: IteratorResult<string> = keys.next();
        while( resultKey.done == false ){
            this.totalAb ++;//统计本次需要加载的Ab包
            this.total += (resPkg.get( resultKey.value ) as IResPkgModel).urls.length;
            resultKey = keys.next();
        }
        keys = resPkg.keys();
        resultKey = keys.next();
        while ( resultKey.done == false ){
            this.loadAssetsBundle( resultKey.value , () => {
                this.nowAb ++;
                if( this.nowAb === this.totalAb){
                    this.loadAssetsInAssetsBundle( resPkg );
                }
            } );
            resultKey = keys.next();
        }
        //end
    }
    private loadAssetsBundle( abName: string, endFunc: () => void ): void{
        assetManager.loadBundle( abName, ( err, bundle ) => {
            if( err != null ){
                console.log(`[ResMgr]: Load AssetsBundle Error: ${abName}`);
                if( this.abBunds.has( abName ) ){
                    this.abBunds.delete( abName );
                }
            }else{
                console.log(`[ResMgr]: Load AssetsBundle Success: ${abName}`);
                this.abBunds.set( abName, bundle );
            }
            if( endFunc ){
                endFunc();
            }
        } );
    }
    private loadAssetsInAssetsBundle( resPkg: Map<string,IResPkgModel> ): void{
        let  keys: IterableIterator<string> = resPkg.keys();
        let resultKey: IteratorResult<string> = keys.next();
        let resultValue: IResPkgModel;
        let urlSet: Array<string>;
        let typeClass: Asset;
        while ( resultKey.done == false ){
            resultValue = resPkg.get( resultKey.value ) as IResPkgModel;
            urlSet = resultValue.urls;
            typeClass = resultValue.assetType;
            for ( let i: number = 0; i < urlSet.length; i ++ ){
                if( this.abBunds.has(resultKey.value) ){
                    this.loadRes( this.abBunds.get(resultKey.value) as AssetManager.Bundle, urlSet[i], typeClass );
                }
            }
            resultKey = keys.next();
        }
    }
    private loadRes( abBundle: AssetManager.Bundle, url: string, typeClass: Asset ): void{
        //@ts-ignore
        abBundle.load( url, typeClass,(error, asset) => {
            this.now++;
            if (error) {
                console.log(`load Res ${url} error : ${error}`);
            } else {
                console.log(`load Res ${url}  sucess!`);
            }
            this.progressFunc && this.progressFunc(this.now, this.total);
            if (this.now >= this.total) {
                this.endFunc && this.endFunc();
            }
        } );
    }
    /**
     * 获取包内资源
     * @param abName
     * @param url
     */
    public getAsset<T extends Asset>( abName: string, url: string): T|null{
        let bondule: AssetManager.Bundle|null = assetManager.getBundle(abName);
        if( bondule == null ){
            console.log( `[error]: ${abName} AssetsBundle not loaded!!!` );
            return null;
        }
        return bondule.get( url );
    }
}

