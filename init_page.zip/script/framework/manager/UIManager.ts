import { _decorator, Component, Node, Button, instantiate, Prefab } from 'cc';
import { ResManager } from './ResManager';
const { ccclass, property } = _decorator;


export class UIController extends Component {
    protected view  = {};

    load_all_object(root, path){
        for(let i= 0; i<root.childrenCount; i++){
           this.view[path + root.children[i].name] = root.children[i];
           this.load_all_object(root.children[i],path + root.children[i].name + "/")
        }
    }

    onload(){
        this.view = {};
        this.load_all_object(this.node,"");
    }

    public add_button_listen(view_name,caller,func){
        var view_node: Node =  this.view[view_name];
        if(!view_node){
            return;
        }
        var button: Button = view_node.getComponent(Button);
        if(!button){
            return;
        }
        view_node.on("click",func, caller);
    }

}



export class UIManager extends Component {
    private canvas : Node = null;
    public static instance : UIManager = null as unknown as UIManager;
    private uiMap = {};
    onload(): void{
        if(UIManager.instance===null){
            UIManager.instance = this;
        }else{
            this.destroy();
            return;
        }
        this.canvas = this.node.parent;

    }

    public showUI(ui_name,parent?:Node): Node {
        if(!parent){
            parent  = this.canvas;
        }
        var prefab: Prefab = ResManager.instance.getAsset("GUI","UIPrefab/"+ui_name);
        var item = null;
        if(prefab){
            item = instantiate(prefab);
            parent.addChild(item);
            item.addComponent(ui_name+"Controller");
        }
        this.uiMap[item] = item;
        return item;

    }

    public removeUI(ui_name){
        if(this.uiMap[ui_name]){
            this.uiMap[ui_name].removeFromParent();
            this.uiMap[ui_name] = null;
        }

    }

    public cleanAll(){
        for(var key in this.uiMap){
            if(this.uiMap[key]){
                this.uiMap[key].removeFromParent();
                this.uiMap[key] = null;
            }
        }

    }
}

