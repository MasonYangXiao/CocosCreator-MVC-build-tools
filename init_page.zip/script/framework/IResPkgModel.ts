import { Asset } from "cc";

export interface IResPkgModel{
    /**资源类型*/
    assetType: Asset;
    /**资源地址*/
    urls: Array<string>;
}

