import { _decorator, Component, Node } from 'cc';
import { AudioManager } from './framework/manager/AudioManager';
import { ResManager } from './framework/manager/ResManager';
import { UIManager } from './framework/manager/UIManager';
import { GameApp } from './game/GameApp';
const { ccclass, property } = _decorator;

//启动入口
@ccclass('main')
export class Main extends Component {

    public static instance : Main = null as unknown as Main;
    onload(): void{
        if(Main.instance===null){
            Main.instance = this;
        }else{
            this.destroy();
            return;
        }
        //加载日志模块 加载网络模块 协议模块 音乐模块
        this.node.addComponent(ResManager)
        //UI视图管理模块
        this.node.addComponent(UIManager);
        //end

        
        this.node.addComponent(GameApp)
    }
    start() {
        //检查资源更新
        console.log("开始了")
        GameApp.instance.startGame();
    }
}

