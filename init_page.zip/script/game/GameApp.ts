import { _decorator, Component, Node } from 'cc';
const { ccclass, property } = _decorator;

export class GameApp extends Component {


    public static instance : GameApp = null as unknown as GameApp;

    onload(): void{
        if(GameApp.instance===null){
            GameApp.instance = this;
        }else{
            this.destroy();
            return;
        }
    }
    
    public initGame() {
        //游戏入口

    }

    //开始游戏
    public startGame() {
        //显示登录界面
        //加载ui资源
        //加载游戏场景
    }
}

